# Mervelerdeyiz Dijital Menü
Bu proje Mervelerdeyiz için hazırlanmış dijital menü uygulamasıdır.